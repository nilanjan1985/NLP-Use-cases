class Config:

    message_template = """\
    From: {sent_from}
    To: {sent_to}
    Subject: {subject}
    
    {content}"""
    outlook_port = 587
    email_host = "smtp-mail.outlook.com"