from smtplib import SMTP
from dataclasses import dataclass, asdict
from .config import Config

@dataclass
class EmailContent:
    subject: str
    content: str

@dataclass
class EmailPayload(EmailContent):
    server_sender_email: str
    server_sender_password: str
    sender_email: str
    target_emails: list[str]

    def format_email(self) -> str:
        return Config.message_template.format(
            sent_from=self.sender_email, 
            sent_to=";".join(self.target_emails), 
            subject=self.subject, 
            content=self.content
        )


class EmailSender:

    @staticmethod
    def build_email_content(subject: str, text: str) -> EmailContent:
        # TODO : change this if need be
        return EmailContent(subject=subject, content=text)
    
    @staticmethod
    def build_email_payload(
        email_content: EmailContent, 
        server_sender_email: str, 
        server_sender_password: str,
        sender_email: str,
        target_emails: list[str]
    ) -> EmailPayload:
        # TODO : change this if need be
        if not server_sender_email.endswith("@gds.ey.com") and not server_sender_email.endswith("@outlook.com"):
            raise ValueError("Sender email must end with either '@gds.ey.com' or '@outlook.com'")
        return EmailPayload(
            **asdict(email_content), 
            server_sender_email=server_sender_email, 
            server_sender_password=server_sender_password,
            sender_email=sender_email,
            target_emails=target_emails
        )

    @staticmethod
    def send_email(email_payload: EmailPayload) -> None:
        server = SMTP(host=Config.email_host, port=Config.outlook_port)
        server.starttls()
        server.login(email_payload.sender_email, email_payload.server_sender_password)
        server.sendmail(
            from_addr=email_payload.sender_email, 
            to_addrs=email_payload.target_emails, 
            msg=email_payload.format_email()
        )
        server.close()

"""
from email_sender.utils import EmailSender, EmailContent, EmailPayload

subject = "Test"
content = "Hello test!!"
server_sender_email = "nilanjan-sender@outlook.com"
server_sender_password = "LX5m3NLPcBr52Rg"
sender_email = "Nilanjan.Mukherjee@gds.ey.com"
target_emails = [server_sender_email]

email_content = EmailSender.build_email_content(text=content, subject=subject)
email_payload = EmailSender.build_email_payload(
    email_content=email_content, 
    server_sender_email=server_sender_email, 
    server_sender_password=server_sender_password,
    sender_email=sender_email,
    target_emails=target_emails
)

EmailSender.send_email(email_payload=email_payload)
"""
# EMAIL : nilanjan-sender@outlook.com
# PASSWORD : LX5m3NLPcBr52Rg